# ID: 53048823
""" Проверил flake8 и pycodestyle, сообщение об ошибке отсутствуют"""


import math


OPERATORS = {'+': lambda x, y: x + y,
             '-': lambda x, y: x - y,
             '*': lambda x, y: x * y,
             '/': lambda x, y: x / y,
             '%': lambda x, y: x % y,
             '^': lambda x, y: x ** y
             }


class Stack:
    def __init__(self):
        self.operands = []

    def push(self, operand):
        self.operands.append(operand)

    def pop(self):
        try:
            return self.operands.pop()
        except IndexError:
            raise IndexError('Недостаточно операндов для вычисления.')

    def size(self):
        return len(self.operands)


def my_int(value):
    if isinstance(value, str):
        return int(value)
    return math.floor(value)


def calculator(seq, operators=OPERATORS):
    s = Stack()
    for symbol in seq.split():
        if symbol in operators:
            num2, num1 = s.pop(), s.pop()
            try:
                s.push(my_int(operators[symbol](num1, num2)))
            except ZeroDivisionError:
                raise ZeroDivisionError(
                    f'Деление на 0 при вычислении {num1} / 0.')
        else:
            s.push(my_int(symbol))
    return s.pop()


def input_data(file_name):
    with open(file_name, 'r') as data:
        seq = data.readline()
        print(calculator(seq))


if __name__ == '__main__':
    input_data('input.txt')
