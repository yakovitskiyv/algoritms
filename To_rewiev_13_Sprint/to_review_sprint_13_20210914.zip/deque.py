# ID: 53048705
""" Проверил flake8 и pycodestyle, сообщения об ошибке отсутствуют"""


class My_deque_sized:
    def __init__(self, values_num):
        self.queue = [None] * values_num
        self.max_n = values_num
        self.head = 0
        self.tail = 0
        self.size = 0

    def is_empty(self):
        return self.size == 0

    def is_full(self):
        return self.size == self.max_n

    def push_front(self, value):
        if self.is_full():
            return 'error'
        self.head = (self.head - 1) % self.max_n
        self.queue[self.head] = value
        self.size += 1

    def push_back(self, value):
        if self.is_full():
            return 'error'
        self.queue[self.tail] = value
        self.tail = (self.tail + 1) % self.max_n
        self.size += 1

    def pop_front(self):
        if self.is_empty():
            return 'error'
        pop_value = self.queue[self.head]
        self.head = (self.head + 1) % self.max_n
        self.size -= 1
        return pop_value

    def pop_back(self):
        if self.is_empty():
            return 'error'
        pop_value = self.queue[self.tail-1]
        self.tail = (self.tail - 1) % self.max_n
        self.size -= 1
        return pop_value


def input_data(file_name):
    with open(file_name, 'r') as data:
        command_num = int(data.readline())
        values_num = int(data.readline())
        data = data.read().splitlines()
        d = My_deque_sized(values_num)

        def print_result(value):
            if value is not None:
                print(value)

        for command in data:
            if 'pop_front' in command:
                print_result(d.pop_front())
            elif 'pop_back' in command:
                print_result(d.pop_back())
            elif 'push_front' in command:
                command = command.strip().split()
                result = d.push_front(int(command[1]))
                print_result(result)
            elif 'push_back' in command:
                command = command.strip().split()
                result = d.push_back(int(command[1]))
                print_result(result)
            else:
                print(
                    f'Комманда {command.split()[0]} не поддерживается.')


if __name__ == '__main__':
    input_data('input.txt')
